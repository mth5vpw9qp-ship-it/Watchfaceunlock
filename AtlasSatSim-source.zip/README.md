# Atlas Sat Sim iOS app

This is a local UI for the host simulator's four scripted scenarios. It has no networking, CommCenter integration, device-management capability, private entitlement, or satellite transmission path. It is not a jailbreak app and cannot enable satellite SOS.

## Build and sign on macOS

1. Open `AtlasSatSim.xcodeproj` in Xcode.
2. Select the `AtlasSatSim` target and set your own signing team and bundle identifier.
3. Select a connected device or a simulator and build/run. For an IPA, use **Product → Archive**, then **Distribute App** and choose the signing/distribution method appropriate for your device.

The project targets iOS 16.0 and later. This workspace runs Windows/WSL and has no Xcode toolchain, so no compiled or signed IPA is included. Validate the project with your Xcode version before installing it.

## Build an unsigned IPA with GitHub Actions

The workflow at `.github/workflows/build-unsigned-ipa.yml` can create an unsigned IPA on a GitHub-hosted macOS runner. To keep the Atlas repository private and limit the uploaded source, place the contents of this `ios/AtlasSatSim` directory at the root of a private repository, then run **Actions → Build unsigned iOS package → Run workflow**. The run produces an `AtlasSatSim-unsigned-ipa` artifact for seven days.

The workflow has no signing credentials and does not sign the app. The resulting IPA must be signed with your own Apple development identity and provisioning profile before installing on an iPhone. GitHub-hosted macOS runner usage can consume included Actions minutes or incur charges depending on the account plan and usage; check the account's Actions billing before starting a run. This workspace has no connected repository or macOS CI account, so the workflow is prepared locally but has not been uploaded or run.

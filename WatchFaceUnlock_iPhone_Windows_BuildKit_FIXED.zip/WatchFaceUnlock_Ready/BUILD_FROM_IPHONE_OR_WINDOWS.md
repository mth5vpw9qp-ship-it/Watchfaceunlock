# Build the unsigned IPA from an iPhone or Windows PC

This repository is built by GitHub Actions on a hosted macOS runner. You do not need a Mac.

1. Create a GitHub repository.
2. Upload the `WatchFaceUnlock_iOS` directory and the root `.github` directory from this kit, keeping the directory structure unchanged.
3. If GitHub's uploader hides `.github`, create `.github/workflows/build-unsigned-ipa.yml` using **Add file → Create new file** and paste in the workflow included in this kit.
4. Go to **Actions** → **Build unsigned iOS IPA** → **Run workflow**.
5. Open the completed run and download the `WatchFaceUnlock-unsigned-IPA` artifact.
6. Extract the artifact ZIP to obtain `WatchFaceUnlock-unsigned.ipa`.
7. Sign the IPA with your signing tool before installing it.

The workflow also uploads a `WatchFaceUnlock-build-log` artifact if the build fails. Share that log to troubleshoot it.

**Important:** The IPA is unsigned. This app is a read-only research tool; it does not enable Hermès faces or bypass Apple's restrictions.

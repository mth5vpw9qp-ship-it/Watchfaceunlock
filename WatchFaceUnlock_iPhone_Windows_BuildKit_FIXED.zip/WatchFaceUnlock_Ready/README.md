# WatchFaceUnlock — iPhone/Windows build kit

This kit is arranged for GitHub Actions: the workflow is in the repository-root `.github/workflows` directory, where GitHub can detect it. The iOS app project is in `WatchFaceUnlock_iOS/`.

## What it builds

A read-only SwiftUI research utility that imports a user-selected MobileGestalt plist and scans user-selected extracted firmware files for Hermès/NanoTimeKit/face-eligibility strings. It does **not** unlock Hermès faces, patch watchOS, modify MobileGestalt, or access protected watch files.

## Build from an iPhone or Windows PC

1. Create a repository on GitHub.
2. Upload the `WatchFaceUnlock_iOS` folder to the repository, preserving its contents and folder name.
3. Upload the root `.github` folder too. If your upload method hides dot-folders, create `.github/workflows/build-unsigned-ipa.yml` in GitHub using **Add file → Create new file**, then paste the workflow from this kit.
4. Open **Actions** → **Build unsigned iOS IPA** → **Run workflow**.
5. When it completes, open the run and download the `WatchFaceUnlock-unsigned-IPA` artifact. GitHub wraps artifacts in a ZIP; extract it to get `WatchFaceUnlock-unsigned.ipa`.
6. Sign the IPA with your preferred signing tool before installing it.

The build uses a GitHub-hosted macOS 15 runner with Xcode. No Mac is needed on your side. The app is unsigned, so it must be signed before installation.

## If the build fails

The workflow uploads `WatchFaceUnlock-build-log` when a build fails. Download that artifact and share the log so the compile error can be diagnosed.

import SwiftUI
import UniformTypeIdentifiers
import Foundation
import CryptoKit
import Combine

@main
struct WatchFaceUnlockApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct AuditFinding: Identifiable, Sendable {
    let id = UUID()
    let title: String
    let detail: String
    let severity: Severity

    enum Severity: Sendable {
        case info, match, warning
    }
}

@MainActor
final class AuditModel: ObservableObject {
    @Published var findings: [AuditFinding] = []
    @Published var isScanning = false
    @Published var status = "Import a MobileGestalt plist or an extracted watchOS firmware folder."
    @Published var scannedFiles = 0
    @Published var matchedFiles = 0

    private let terms = [
        "Hermes", "Hermès", "NTKHermes", "supportsFall2025FacesCapability",
        "isRestrictedForDevice", "deviceCategory", "collectionType",
        "FaceStyleIsAvailable", "NanoTimeKit", "Hermes2025Face"
    ]

    func analyzePlist(url: URL) {
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }

        do {
            let data = try Data(contentsOf: url)
            let object = try PropertyListSerialization.propertyList(from: data, options: [], format: nil)
            var output: [AuditFinding] = [
                .init(title: "Plist loaded", detail: "\(url.lastPathComponent) · \(data.count) bytes", severity: .match)
            ]
            if let dict = object as? [String: Any] {
                output.append(.init(title: "Top-level keys", detail: dict.keys.sorted().joined(separator: ", "), severity: .info))
                for key in ["CacheUUID", "CacheData", "CacheExtra"] {
                    guard let value = dict[key] else { continue }
                    if let bytes = value as? Data {
                        output.append(.init(title: key, detail: "\(bytes.count) bytes · SHA-256 \(Self.sha256(bytes))", severity: .info))
                    } else {
                        output.append(.init(title: key, detail: String(describing: value), severity: .info))
                    }
                }
                let serialized = String(describing: dict)
                for term in ["DeviceBrand", "Hermes", "Fall2025", "Watch"] {
                    output.append(.init(title: "Contains \(term)", detail: serialized.localizedCaseInsensitiveContains(term) ? "Found in plist representation" : "Not found in plist representation", severity: serialized.localizedCaseInsensitiveContains(term) ? .match : .info))
                }
            } else {
                output.append(.init(title: "Plist root", detail: "Root object is not a dictionary.", severity: .warning))
            }
            findings = output
            status = "Plist analysis complete. No files were modified."
        } catch {
            findings = [.init(title: "Could not read plist", detail: error.localizedDescription, severity: .warning)]
            status = "Plist analysis failed."
        }
    }

    func analyzeFolder(url: URL) {
        let granted = url.startAccessingSecurityScopedResource()
        isScanning = true
        findings = []
        scannedFiles = 0
        matchedFiles = 0
        status = "Scanning extracted firmware…"

        Task.detached(priority: .userInitiated) { [terms] in
            var results: [AuditFinding] = []
            var fileCount = 0
            var hitCount = 0
            let keys = Set(terms.map { $0.lowercased() })
            let fm = FileManager.default
            let enumerator = fm.enumerator(at: url, includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey], options: [.skipsHiddenFiles, .skipsPackageDescendants])
            while let file = enumerator?.nextObject() as? URL {
                let values = try? file.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
                guard values?.isRegularFile == true,
                      let size = values?.fileSize,
                      size <= 80 * 1024 * 1024 else { continue }
                guard let data = try? Data(contentsOf: file, options: [.mappedIfSafe]) else { continue }
                fileCount += 1
                let text = String(decoding: data, as: UTF8.self)
                let lower = text.lowercased()
                let hits = keys.filter { lower.contains($0) }.sorted()
                if !hits.isEmpty {
                    hitCount += 1
                    let relative = file.path.replacingOccurrences(of: url.path + "/", with: "")
                    let sample = hits.joined(separator: ", ")
                    results.append(.init(title: relative, detail: "Matched: \(sample)", severity: .match))
                }
            }
            await MainActor.run {
                self.scannedFiles = fileCount
                self.matchedFiles = hitCount
                self.findings = results.sorted { $0.title < $1.title }
                self.status = "Scan complete. \(fileCount) files scanned; \(hitCount) files matched. No files were modified."
                self.isScanning = false
                if granted { url.stopAccessingSecurityScopedResource() }
            }
        }
    }

    private static func sha256(_ data: Data) -> String {
        // CryptoKit is available on supported iOS versions.
        importCryptoKitSHA256(data)
    }

    private static func importCryptoKitSHA256(_ data: Data) -> String {
        let digest = SHA256.hash(data: data)
        return digest.map { String(format: "%02x", $0) }.joined()
    }
}

struct ContentView: View {
    @StateObject private var model = AuditModel()
    @State private var showImporter = false
    @State private var importKind: ImportKind = .plist

    enum ImportKind { case plist, folder }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("WatchFaceUnlock")
                            .font(.largeTitle.bold())
                        Text("Apple Watch SE 2 · watchOS 26.6 · 23U67")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text("Read-only research utility. It does not unlock faces, patch watchOS, or modify MobileGestalt.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 6)
                }

                Section("Choose input") {
                    Button {
                        importKind = .plist
                        showImporter = true
                    } label: {
                        Label("Analyze MobileGestalt plist", systemImage: "doc.text.magnifyingglass")
                    }
                    Button {
                        importKind = .folder
                        showImporter = true
                    } label: {
                        Label("Scan extracted firmware folder", systemImage: "folder.badge.gearshape")
                    }
                }

                Section("Status") {
                    Text(model.status)
                        .font(.subheadline)
                    if model.isScanning {
                        ProgressView()
                    }
                    if model.scannedFiles > 0 {
                        LabeledContent("Files scanned", value: "\(model.scannedFiles)")
                        LabeledContent("Files with matches", value: "\(model.matchedFiles)")
                    }
                }

                Section("Findings") {
                    if model.findings.isEmpty {
                        ContentUnavailableView("No findings yet", systemImage: "waveform.path.ecg", description: Text("Import a plist or extracted firmware folder to begin."))
                    } else {
                        ForEach(model.findings) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(item.title).font(.headline)
                                    Spacer()
                                    Image(systemName: icon(for: item.severity))
                                        .foregroundStyle(color(for: item.severity))
                                }
                                Text(item.detail)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .textSelection(.enabled)
                            }
                            .padding(.vertical, 3)
                        }
                    }
                }

                Section("Important limitations") {
                    Text("A missing string does not prove a component is absent. Firmware extractions can omit cryptexes, shared caches, or separately mounted components.")
                    Text("Finding a string does not prove the associated check is reachable or that bypassing it is sufficient.")
                    Text("This app only reads user-selected files. It cannot access protected watchOS files or change watch settings.")
                }
            }
            .navigationTitle("Research")
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(
                isPresented: $showImporter,
                allowedContentTypes: importKind == .plist ? [.propertyList, .xml, .data] : [.folder],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    if importKind == .plist {
                        model.analyzePlist(url: url)
                    } else {
                        model.analyzeFolder(url: url)
                    }
                case .failure(let error):
                    model.status = "Import failed: \(error.localizedDescription)"
                }
            }
        }
    }

    private func icon(for severity: AuditFinding.Severity) -> String {
        switch severity {
        case .info: return "info.circle"
        case .match: return "checkmark.circle.fill"
        case .warning: return "exclamationmark.triangle.fill"
        }
    }

    private func color(for severity: AuditFinding.Severity) -> Color {
        switch severity {
        case .info: return .secondary
        case .match: return .green
        case .warning: return .orange
        }
    }
}

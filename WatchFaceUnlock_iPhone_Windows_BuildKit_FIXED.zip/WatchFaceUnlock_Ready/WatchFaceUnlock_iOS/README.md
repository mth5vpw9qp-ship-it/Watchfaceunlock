# WatchFaceUnlock iOS project

Native SwiftUI iPhone research utility for the Apple Watch SE 2 / watchOS 26.6 (23U67) investigation.

## Features
- Import and inspect a user-selected MobileGestalt plist.
- Report top-level keys and cache metadata when present.
- Scan a user-selected extracted firmware directory for Hermès/NanoTimeKit/face-eligibility strings.
- Read-only operation: it does not patch the watch, modify MobileGestalt, access protected files, or unlock faces.

## Build target
- iOS 17.0 or later
- Swift 5 language mode
- No third-party packages; CryptoKit is provided by Apple SDKs

The shared Xcode scheme is `WatchFaceUnlock`. The GitHub Actions workflow at the repository root builds an unsigned device app and packages it as an IPA.

## Limitations
A missing string does not prove a component is absent. A matching string does not prove that a check is reachable or that bypassing it is sufficient. iOS apps cannot directly access protected watchOS system files or change watch face eligibility; the user must provide files through the document picker.
